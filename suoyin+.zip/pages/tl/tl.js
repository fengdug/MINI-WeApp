const app = getApp();
var dot = 0;
var time = 0;
var interver = '';





Page({

  /**
   * 页面的初始数据
   */
  data: {
    openid: '',
    userInfo: {},
    hasUserInfo: false,
    current: "school",
    over:false,


    //下面是页面侧栏内容
    open: false,
    // mark 是指原点x轴坐标
    mark: 0,
    // newmark 是指移动的最新点的x轴坐标 
    newmark: 0,
    istoright: true,
    windowWidth: wx.getSystemInfoSync().windowWidth,

    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    wen:[
      {
        concent:"          男女之间为何绝大多数人选择婚姻？因为爱情是短暂的，它会被时间稀释，当然美观点说你也可以管那叫升华。婚姻是给两房家族一个交代，也是给自己名誉的一份认可，更关键的是要给未来的孩子一个责任。恋爱是为自己谈的，可结婚是给别人结的。婚姻能保护很多东西却不保险爱情本身，所以请误以为结婚=幸福"
      },{
        concent: "千万不要混几天社会，认识几个狐朋狗友听他们吹吹牛逼…就误以为自己朋友很多，人脉很广，开始得瑟作，出了事有官僚子弟照着。这种想法太鸡吧幼稚了…无论你是啥人物，一旦落难，能为你冲出来的就只有你那哆哆嗦嗦的老爹老娘。人生感悟，仅供参考。"
      },{
        concent: "我个人对教师这个职业的确存在极大敌意，因我成长之路遇过为人师表者凤毛麟角！大部分教师偏袒势力，体罚学生，收受贿赂，私设补习，漫天收费，在中国从小学到大学，入学需重金+人脉走后门已经是几十年来全民默许的老规矩，绝非个别现象，这就是中国教育界腐烂到骨子里的现状，这比政治腐败更祸国。"
      },{
        concent: "记住，不要轻易去骂一个孩子丑！第一，小孩长大出落成啥样谁也说不准。第二，青春就是人类最美的衣裳，干干净净的孩子没有丑的。第三，发育中的孩子三观还未成型，被人骂丑会在孩子心中栽下自卑的根。自卑是怨恨的种子，自卑是敏感的胞胎，自卑是可悲的萌芽…用攻击孩子的外形来满足自己的平衡感，缺德"
      },{
        concent: "脑残常喜欢抢占道德高地，然后毫无依据仅凭别人的谣传就在那批判这个人品不成，那个人品不正，一幅我在你家装过监控，你的人生我最懂的意淫嘴脸。人品是什么？人品是你跟一人同床十年，不离婚你不了解他人品。人品是你俩磕头斩鸡拜了把子，不遇上事时你根本看不清他的人品。别轻易评断谁的人品，人品是相处半辈子都未必看透的东西，素未谋面的你咋知道的？你人品好你TM倒是干点人事去啊…越是下三滥的人种越喜欢标榜三观，他们也知道自己除了这个别的牛逼吹不起。"
      },{
        concent: "请相信，90后里也有大把人才对琴棋书画，诗词风雅，古董家私，甚至你们认为是中老年才感兴趣的精品配饰，玉石珠翠…涉猎极深。这不代表你比他年轻，只代表他比你更懂得鉴赏。更不要指着别人的品味说那是你爸爸才会喜欢的，误以为我low故我在。你可知你爹混了大半辈子终于和某些人一出生的品味持平了。"
      },{
        concent: "真正的弱者，就只会用最愚蠢的方式欺负自己最亲近的人。好比幼儿常用不吃饭吓唬自己的妈妈。好比有些人总把分手挂在嘴边去威胁最爱自己的人，逼对方无底线的向自己妥协。好比窝囊的醉汉在外面受了气就回家打骂老婆来宣泄自己的不得志。能吃你这套的人都是你仅有的财富，毁掉后你会发现自己一无所有。"
      },{
        concent: "人一定要追求内涵，虽然内涵这个词放在柴米油盐的日子里显得挺装逼的，但是没有内涵你会被有内涵+比你还没内涵的人=共同瞧不起。不要以为瞧不起你的都是外人，无关痛痒。你的朋友，家人，尤其是你爱人同样是瞧不起你的，只不过他们摊上了你也就认命罢了。你知道他们对你很好但你也清楚他骨子里瞧不起你"
      },{
        concent: "人活一世，依靠是门大学问。靠父母是你前世造化，靠朋友是你今世人品，靠爱人是你个人魅力…靠谁不重要，重要的是你能因此成就自己。成功者都在感恩贵人，失败者永远潜台词“老子靠自己，所以混的狗屁不是也是应该的” 。祝各位年轻时有靠山，老了也是别人的靠山"
      }, {
        concent: "钱是一个你得有了之后才配谈看重&看淡的东西，富人有境界高的开始追求灵魂信仰，也有境界低的就混酒池肉林。但是你让一穷鬼不贪财，合乎逻辑么？就像你不能要求一个婴儿看破红尘。在钱上绝大多数人一辈子都是婴儿状态，所以他们一边仇富一边骗自己说“有钱买不来快乐”。就像贫穷TM=快乐一样。"
      }, {
        concent: "我不知从什么时候起开始流行，人人都要把自己伪装成一个逗逼，把自己编造成各种段子取悦陌生人欢笑，而大多数人也渐渐认为没事就扮猫扮狗给大家秀一出的人…才叫接地气+人品好+三观正。如果这就是大势所趋，那么我愿做第一个被时代淘汰的老人。看见那些张嘴醉了，闭嘴没什么卵用的人，就本能鄙视讨厌。"
      }, {
        concent: "许多人的快感源自别人的劫难…其实他们嘴巴说着“你看，钱有何用”时内心自然清楚穷人也会生病，医疗机构不会因为你穷就免费救治你。但他们就想趁机舔舔自己的精神伤口，在每个成功人士不爽的时候自己爽爽。"
      }, {
        concent: "性幻想是什么？性幻想就是当你遇到了一个人，不知道他的身家背景就已被他吸引，就算他清贫的你同样渴望占有他的肉体和情绪。甚至你甘愿倒贴去一亲芳泽你也觉得值！他就是一个可以送你上欲望高潮的人。至于那些幻想霸道总裁的妹子…你们那不叫性幻想，你们只是穷怕了而已。"
      }, {
        concent: "聊文学要你博览群书，聊历史要你博古通今，聊旅游要你行万里路，聊艺术要你有美学底蕴，就连聊美食还需要你不差钱且懂生活呢，琴棋书画吃喝玩乐都TM玩不起的人最喜欢叫嚣的就是爱国了。1爱国可以暂时遮掩他无法参与讨论的无知。2大部分人喊爱国是因为对自己的生活极度自卑，其实他谁也不爱，内心全是恨"
      }, {
        concent: "只有最没出息的人才会终日窥探他人的生活，期盼对方能够低调一点好让自己内心平衡，生怕别人得了虚名后距离自己更加遥远，殊不知谁人高低调你仍是你，一样的不在调上。就仿佛某某艺人风头正劲时总有乌合之众集体意淫人家靠睡觉得来成果，不敢用脑想想若睡觉是成功之本，中国还哪有三陪小姐？"
      }, {
        concent: "一个人如果连坦然面对自己丑恶面勇气都没有，这个人不可能有所担当，因为他不知道自己究竟要担当些什么。他也不会有真正的朋友，因为他的朋友全部要建立在倾心其谎言的基础上，一旦被识破，他轻则疏远决裂，重则杀人灭口。所有的专横只能证明他的怯懦。渴望被了解又恐惧被真正的了解，心魔最难甩。"
      }, {
        concent: "碌碌无为的人总喜欢指着别人的成绩不屑的说“Ta不就靠什么，什么…”。否定别人的才能和努力的同时也舔舔自己那不得志的伤口。其实这世界没有任何资本是可以让你依靠到成功为止的，找到一种依靠只是你奋斗的第一步，后面还有千百个艰辛的脚印要靠你自己踩…只是很多人一辈子连这步都没勇气和资本迈出去"
      }
    ],
  },


    onLoad: function () {
  //初始加载获取用户信息函数
      if (app.globalData.userInfo) {
        this.setData({
          userInfo: app.globalData.userInfo,
          hasUserInfo: true
        })
      } else if (this.data.canIUse) {
        app.userInfoReadyCallback = res => {
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      } else {
        // 在没有 open-type=getUserInfo 版本的兼容处理
        wx.getUserInfo({
          success: res => {
            app.globalData.userInfo = res.userInfo
            this.setData({
              userInfo: res.userInfo,
              hasUserInfo: true
            })
          }
        })
     }
  //初始加载获取用户信息函数

  },

  //获取用户信息逻辑
    getUserInfo: function (e) {
      console.log(e)
      app.globalData.userInfo = e.detail.userInfo
      this.setData({
        userInfo: e.detail.userInfo,
        hasUserInfo: true
      })
    },
  //获取用户信息逻辑

  //TAB切换--逻辑
    tab: function (event) {
      this.setData({ current: event.target.dataset.current })
    },
    //滑动事件
    eventchange: function (event) {
      this.setData({ current: event.detail.current })
    },
  //TAB切换--逻辑

  //---------下拉加载逻辑----------------
    onPullDownRefresh: function () {
      wx.showNavigationBarLoading()//标题栏显示加载中
      setTimeout(function () {
        wx.hideNavigationBarLoading()//完成后停止加载
        wx.stopPullDownRefresh()//停止下拉刷新
      }, 400);
    },
 //---------下拉加载逻辑----------------


  back:function(){
    this.setData({
      open:false
    })
  },


  //左侧抽屉


  tap_ch: function (e) {
    if (this.data.open) {
      this.setData({
        open: false
      });
    } else {
      this.setData({
        open: true
      });
    }
  },
  tap_start: function (e) {
    // touchstart事件
    this.data.mark = this.data.newmark = e.touches[0].pageX;
  },
  tap_drag: function (e) {
    // touchmove事件

    /*
     * 手指从左向右移动
     * @newmark是指移动的最新点的x轴坐标 ， @mark是指原点x轴坐标
     */
    this.data.newmark = e.touches[0].pageX;


    if ((this.data.mark < this.data.newmark) &&(this.data.windowWidth * 0.75) >(this.data.newmark - this.data.startmark)){
      this.istoright = true;
    } 
    /*
     * 手指从右向左移动
     * @newmark是指移动的最新点的x轴坐标 ， @mark是指原点x轴坐标
     */
    if (this.data.mark > this.data.newmark) {
      this.istoright = false;
    }
    this.data.mark = this.data.newmark;

  },
  tap_end: function (e) {
    // touchend事件
    this.data.mark = 0;
    this.data.newmark = 0;
    if (this.istoright) {
      this.setData({
        open: true
      });
    } else {
      this.setData({
        open: false
      });
    }
  } 
})