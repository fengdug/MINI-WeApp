// shezhi/shezhi.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imgs:null,
    pic: ["https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=3711094719,3753165190&fm=200&gp=0.jpg","https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=3554129370,1227121491&fm=26&gp=0.jpg"]
  },
  choosetupian:function(){
    var that = this ;
    wx.chooseImage({
      count: 2,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
        success: function (res) {
          var temFilePaths = res.tempFilePaths;
          wx.showLoading({
            title: '设置中',
            }),
          that.setData({
            imgs: temFilePaths
          });
          wx.setStorageSync(imgs, res.temFilePaths)
         },
        fail:function(){
         wx.showToast({
          icon: 'none',
          title: '设置失败',
         })
        },
        complete:function(){
          wx.hideLoading();
         }
    })
  },
  previewImage:function(e){
    var that = this ,
    index = e.currentTarget.dataset.index,
    pictures = this.data.pictures;
    wx.previewImage({
      current:pictures[index],
      urls: [pictures],
    })
  },
  tip:function(){
    var wenzi ="这个部分可以从相册选择学生证头像页，校园卡正面的图片，以用作身份认证，仅支持添加两张图片，存在本地（如果不经意清楚微信全部数据，可能需要再次添加，以备不时只需。"
    wx.showModal({
      titlve: '关于',
      content: wenzi,
      showCancel: false,
      confirmText: '了解',
      confirmColor: 'green',
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  },
  swichtap: function () {
    wx.navigateBack({
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.showShareMenu({
      withShareTicket: true,
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})