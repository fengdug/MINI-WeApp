// shezhi/guanyu.js
Page({

  /** 页面的初始数 */
  data: {
    biaoti: "写在前面",
    neirong: [
          "人区别于一般动物的伟大之处在于人会理性思考，会反思。\n 关于信息的获取、掌握、分析、处理与预测能力贯穿成人始终，希望它可以给你带来方便。\n\n这个小程序来自一个被图书馆摩擦千百次的小哥哥（他现在还好）, 他致力于让每个进入图书馆向学的宝宝有选择呆一会儿再出去的权力。不至于因为人为原因和无座影响心情。   \n\n小哥哥在总结对外经贸、重大等实践经验的基础上 0基础开发， 去繁就简，实属不易，觉得好用，就请小哥哥喝杯奶茶吧。\n\n如果你有更好的建议，欢迎致信fengdug26@163.com \n\n","1243523"
        ],
   //-----弹窗数据---
    showModalStatus: false,
      },
//弹窗逻辑实现
  powerDrawer: function (e) {
    var currentStatu = e.currentTarget.dataset.statu;
    this.util(currentStatu)
  },
  util: function (currentStatu) {

    var animation = wx.createAnimation({
      duration: 200,
      timingFunction: "linear",
      delay: 0
    });
    this.animation = animation;
    animation.opacity(0).rotateX(-100).step();
    this.setData({
      animationData: animation.export()
    })


    setTimeout(function () {
      animation.opacity(1).rotateX(0).step();
      this.setData({
        animationData: animation
      })
      if (currentStatu == "close") {
        this.setData(
          {
            showModalStatus: false
          }
        );
      }
    }.bind(this), 200)
    if (currentStatu == "open") {
      this.setData(
        {
          showModalStatus: true
        }
      );
    }
  },
      
  save1: function () {
    wx.getImageInfo({
      src: '../../../../image/w.jpg',
      success: function (res) {
        wx.saveImageToPhotosAlbum({
          filePath: res.path,
          success() {
            wx.showToast({
              title: '保存成功',
              icon: 'none'
            })
          },
          fail() {
            wx.showToast({
              title: '保存失败',
              icon: 'none'
            })
          }
        })
      }
    })
  },
  save2: function () {
    wx.getImageInfo({
      src: '../../../../image/z.jpg',
      success:function(res){
        wx.saveImageToPhotosAlbum({
          filePath: res.path,
          success() {
            wx.showToast({
              title: '保存成功',
              icon: 'none'
            })
          },
          fail() {
            wx.showToast({
              title: '保存失败',
              icon: 'none'
            })
          }
        })
      }
    })
  },


//------返回-----
  swichtap: function () {
    wx.navigateBack({
    })
  },

//---------跳转小程序----------------
    retip:function(){
      wx.navigateToMiniProgram({
        appId:"wx0ceba01e2e93e612",
        path:'',
        envVersion:"develop",
        success(res){
          wx.showToast({
            title: '感谢！',
          })
        },
        fail(res){
          wx.showToast({
            title: '期待您的继续支持！',
            icon:"none"
          })
        }
      })
    }
})