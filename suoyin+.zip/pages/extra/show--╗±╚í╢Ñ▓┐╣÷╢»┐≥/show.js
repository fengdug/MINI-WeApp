var dot = 0;
var time = 0;
var interver = '';


Page({
    data: {
      hidden:'true',
      hidden1: 'true',
      //顶部滚动栏参数
      title:[
        "阿里巴巴总部将于11月开工，2024年投入使用",
        "深圳GDP首超香港，成为粤港澳答完区经济总量第一城",
        "教育部：研究生复试全程要求录音录像，现场评分不得改动",
        "国家网信办：几年以来已注销违法违规账号49万余个关闭，取消备案网站1462家",
        "最高检：将推动性侵犯罪信息查询成为教师从业前置程序",
        "巴基斯坦民航局宣布：关闭领空，所有民航航班停飞",
        ],
    },



  
  onShareAppMessage: function () {
    var that = this;
    return {
      title: '信息',
      path: '/pages/show/show',
      imageUrl: 'https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=3326734550,2710182217&fm=26&gp=0.jpg',
      sucess:function(res){
        wx.showToast({
          title: '转发成功',
          icon:'none'
        })
      }
    }
  },




  //---------跳转小程序----------------
    retip: function () {
      wx.navigateToMiniProgram({
        appId: "wx0ceba01e2e93e612",
        path: '',
        envVersion: "develop",
        success(res) {
          wx.showToast({
            title: '感谢！',
          })
        },
        fail(res) {
          wx.showToast({
            title: '期待您的继续支持！',
            icon: "none"
          })
        }
      })
    },
  //---------跳转小程序----------------

 
})





