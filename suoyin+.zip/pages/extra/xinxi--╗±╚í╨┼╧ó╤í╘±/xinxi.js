// xinxi/xinxi.js

Page({
  data: {
  //判断设置信息框体选项
    hidden:'true',
    hidden1:'true',
    hidden2:'true',
    hidden3:'true',
  //个人信息输入框
    sex: ['男', '女'],
    xinqing: ['正常人','见男不爽脸','呵！女人','烦透人类','只想静静',],
    index:0,
    index2:0,
    index3:0,
    xy:[
      { name:"1", value:"经法学院" },
      { name: "2", value: "政史学院" },
      { name: "3", value:"教体学院" },
      { name: "4", value: "工学院" },
      { name: "5", value:"艺院" },
      { name: "6", value:"其他学院" },
      ],
    src:"../../../../image/c.jpg"
  },
  //个人信息设置函数
    sex: function(e) {
      this.setData({
        index : e.detail.value
      });
    },
    xinqing: function (e) {
      this.setData({
        index3: e.detail.value
      });
    },
    xy: function (e) {
      this.setData({
        index2 : e.detail.value
      });
    }, 
    isset:function(){
      this.setData({
        hidden: false, 
        hidden1: 'true',
        hidden2: 'true',
        hidden3: 'true',
      })
    },
    isset1: function () {
      this.setData({
        hidden1: false,
        hidden: 'true',
        hidden2: 'true',
        hidden3: 'true',
      })
    },
    isset2: function () {
      this.setData({
        hidden2: false,
        hidden1: 'true',
        hidden: 'true',
        hidden3: 'true',
      })
    },
  isset3: function () {
    this.setData({
      hidden3: false,
      hidden1: 'true',
      hidden: 'true',
      hidden2: 'true',
    })
  },
    scroll:function(){
      wx.pageScrollTo({
        scrollTop: 1000,
        
      })
    },
   change: function () {
      this.setData({
        hidden:'true',
        hidden1: 'true',
        hidden2: 'true',
        hidden3: 'true',
     })
   },
    reset:function(){
      wx.showToast({
        title: '成功  ‘-ωก̀',
      })
    },
    save:function(res){
      wx.showToast({
        title: '成功  ‘-ωก̀',
      })
    },
    reserve:function(){
      wx.setStorageSync('','');
      wx.setStorageSync('','') ;
      wx.setStorageSync('','');
      wx.setStorageSync('','')     
    },
  swichtap: function () {
    wx.navigateBack({
    })
  },
})